from flask import *
import pymysql
app =  Flask(__name__)
mydb = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="nrcm"
)
if mydb:
    print("Connected")
else:
    print("Not Connected")

@app.route("/")
def login():
    return render_template("nrcm.html")
@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

if __name__ == "__main__":
   app.run(debug=True)

